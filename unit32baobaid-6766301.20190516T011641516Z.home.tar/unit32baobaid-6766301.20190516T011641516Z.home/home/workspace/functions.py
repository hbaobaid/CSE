# a function is a set of directions 

#Function using print statement
def add(num1, num2):
    print(str(num1 + num2))
#Calling functions   
add(5,6)
#Function using return statement
def sub(num1,num2):
    diff = num1 - num2
    return diff
#Calling a return function
difference = sub(10, 7)
print(str(difference))
#Advantage of the return function is that yo can use the return value
multiply = sub(17,5)* 2
print(multiply)