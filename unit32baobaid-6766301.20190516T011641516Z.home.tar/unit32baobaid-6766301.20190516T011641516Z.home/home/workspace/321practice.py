world_list = ['w', 'o', 'r', 'l', 'd']
integers = [-3, -2, -1, 0, 1, 2, 3]
floats = [-5.0, 0.5]
multi_type = ["hello", 2, "the", world_list]
empty = []
print(integers)
print(multi_type)
world_list = [type(0), type(1), type(2), type(3), type(4)] 
print(world_list)
food = ["Burger", "Shake", "Fries"]
print (food[0] + " at index 0")
print (food[1] + " at index 1")
print (food[2] + " at index 2")
print("Is Burger in the list?:")
in_list = "Pizza" in food
print "Is Pizza in the list?: " + str(in_list)
in_list = "Burger" in food
print "Is Burger in the list?: " + str(in_list)
in_list = "Shake" in food
print "Is Shake in the list?: " + str(in_list)
in_list = "Fries" in food
print "Is Fries in the list?: " + str(in_list)
hlist = ["Hisham Baobaid"]
print hlist[0][0],".",hlist[0][7]


