from bunny2 import Bunny
Peter = Bunny('white', 'blue', '50', '5', 'Peter')
print("Peter is a " + Peter.Furr_Color + " bunny with " + Peter.Eye_Color + " eye color and is " + Peter.Weight + " lbs. He is also " + Peter.Age + " years old and his name is " + Peter.Name)
Peter.hop()
Peter.eat_carrot()

Furr_Color = raw_input("What color is the bunny?\n")
Eye_Color = raw_input("What is the bunny's eye color?\n")
Weight = raw_input("How much does the bunny weigh in pounds?\n")
Age = raw_input("How old is the bunny?\n")
Name = raw_input("What is the name of your bunny?:\n")
bunny2 = Bunny(Furr_Color, Eye_Color, Weight, Age, Name)
print(bunny2.Name + " is a " + bunny2.Furr_Color  + " bunny with " + bunny2.Eye_Color + " eye color and is " + bunny2.Weight + " lbs. He is also " + bunny2.Age + " years old and his name is " + bunny2.Name)