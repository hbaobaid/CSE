list = ["HishamBaobaid"]
print list[0][0],list[0][6]
print list[0][-1]
print(len(list[0]))
print (list[[0][6]:])