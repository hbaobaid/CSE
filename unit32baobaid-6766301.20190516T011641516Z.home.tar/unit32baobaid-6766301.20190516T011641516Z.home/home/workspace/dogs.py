#Define Class Properties
class Dog:
    #__init__ is normally the first method
    #it initializes atributes
    def __init__(self, breed, eye_color, size):
        self.breed = breed
        self.eye_color = eye_color
        self.size = size

    #Create methods
    def speak(self):
        print("Baaaaaarrrrrrrrkkkk!")
    def attack(self):
        print("Grrrrrrrrrrrrrrrrrrrrr")
    def dog_age(self,age):
        dage = age * 7
        return dage
    