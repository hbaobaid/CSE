#import class
from dogs import Dog

#create an instant(object) of Dog class
charlie = Dog('Chiawini', 'orange', 'small')
print("Charlie is a " + charlie.breed + " with " + charlie.eye_color + " eyes and he is a " + charlie.size + " dog.")

#Call methods
charlie.speak()
charlie.attack()

#call method with argument/parameter
print('Charlie is: ' + str(charlie.dog_age(5)))

#Create object with user info
breed = raw_input("What is the breed of your dog?|\n")
eye_color = raw_input("What is the eye color of the dog?\n")
size = raw_input ("What is the size of the dog?\n")
sparky = Dog(breed, eye_color, size)
print("Sparky is a " + sparky.breed + " with " + sparky.eye_color + " eyes and he is a " + sparky.size + " dog.")

