x = 0
my_list = [0, 1, 2]
for number in my_list:
    x = x + number 

print x
range(10)
range(1,11)
range(0,30,5)
range(0,10,3)
range(0,-10,-1)
range(0)
range(1,0)