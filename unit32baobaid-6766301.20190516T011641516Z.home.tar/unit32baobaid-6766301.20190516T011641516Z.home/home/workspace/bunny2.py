#Define Class Properties
class Bunny:
     #__init__ is normally the first method
    #it initializes atributes
    def __init__(self, Furr_Color, Eye_Color, Weight, Age, Name):
        self.Furr_Color = Furr_Color
        self.Eye_Color = Eye_Color
        self.Weight = Weight  
        self.Age = Age
        self.Name = Name

    #Create methods
    def bunny_age(self,age):
        bunnyage = age * 10
        return bunnyage
    def hop(self):
        print("Hop Hop Hop")
    def eat_carrot(self):
        print("Crrruunch")