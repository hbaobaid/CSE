#assignment1 fuction

def  assignment1():
    print("Assignment 1 completed!")
    
#assignment 2 function
def assignment2():
    return ("Assignment 2 completed!")

#execute assignment
def execute_assignment(assignment_number):
        if (assignment_number == "1"):
            assignment1()
        if (assignment_number == "2"):
            print (assignment2())
        
        
    
#Call function
assign_num="0"
while assign_num != "quit":
    assign_num = raw_input("Choose an Assignment: 1 or 2\n")
    execute_assignment(assign_num)
    if assign_num == "quit":
        break